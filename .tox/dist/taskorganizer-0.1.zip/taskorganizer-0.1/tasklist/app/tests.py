"""tests.py ."""
# flake8: noqa

from django.test import TestCase

# Create your tests here.
