"""__init.py__."""
# flake8: noqa
from .home import main_page
from .home import signup
from .home import login
from .home import logout

from .task import add_task
from .task import edit_task
from .task import delete_task
