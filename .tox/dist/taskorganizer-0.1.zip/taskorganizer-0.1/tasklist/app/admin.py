"""admin.py ."""
# flake8: noqa
from django.contrib import admin

# Register your models here.
